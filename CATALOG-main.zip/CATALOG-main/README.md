git clone https://github.com/nlohmann/json.git 
for easy JSON Operations in VSCODE.

After cloning , Your directiry must contain json directory.


To run on VSCODE 

 g++ main.cpp -o main -I json/single_include      
.\main.exe

